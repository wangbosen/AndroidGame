package com.ricky.propertyanimation;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

public class MainActivity extends Activity {

	private ImageView iv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		iv = (ImageView)findViewById(R.id.button1);
//		iv.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				Toast.makeText(getApplicationContext(), "���Ҹ�ɶ��", 0).show();
//			}
//		});
		
	}
	
	int position = 0;
	public void startAnimation(View v){
//		Animation animation = AnimationUtils.loadAnimation(this, R.anim.translate);
////		animation.start();
//		bt.startAnimation(animation);
		
		//���Զ���
//		position += 100;
//		v.setTranslationX(position);
//		v.setAlpha((float)Math.random());
		
		//1.---------------------------------------
		/**
		 * float... values: A set of values that the animation will animate between over time.

		 */
//		ObjectAnimator oa = ObjectAnimator.ofFloat(v, "translationX", 0f,300f);
//		oa.setDuration(500);
//		oa.start();
//		ObjectAnimator oa = ObjectAnimator.ofFloat(v, "translationY", 0f,300f);
//		oa.setDuration(500);
//		oa.start();
//		ObjectAnimator oa = ObjectAnimator.ofFloat(v, "rotationX", 0f,360f);
//		oa.setDuration(500);
//		oa.start();
		
		//2.----------------�������ͬʱִ��---�취1�����ö�����������ʼ��һ������ͬʱ������������-----------------
		//����1��
//		ObjectAnimator animator = ObjectAnimator.ofFloat(v, "haha", 0f, 100f);//û��������Ե�ʱ�򣬾���valueanimator
//		animator.setDuration(300);
//		//���ö�������
//		animator.addUpdateListener(new AnimatorUpdateListener() {
//			
//			@Override
//			public void onAnimationUpdate(ValueAnimator animation) {
//				//������ִ�еĹ��̵��У����ϵص��ô˷���
////				animation.getAnimatedFraction()//�ٷֱ�
//				//�õ�durationʱ���� values���е�ĳһ���м�ֵ��0f~100f
//				float value = (float) animation.getAnimatedValue();//
//				iv.setScaleX(0.5f+value/200);//0.5~1
//				iv.setScaleY(0.5f+value/200);//0.5~1
//			}
//		});
//		animator.start();
		
//		animator.addListener(new AnimatorListener() {
//			
//			@Override
//			public void onAnimationStart(Animator animation) {
//				// TODO Auto-generated method stub
//				
//			}
//			
//			@Override
//			public void onAnimationRepeat(Animator animation) {
//				// TODO Auto-generated method stub
//				
//			}
//			
//			@Override
//			public void onAnimationEnd(Animator animation) {
//				// TODO Auto-generated method stub
//				
//			}
//			
//			@Override
//			public void onAnimationCancel(Animator animation) {
//				// TODO Auto-generated method stub
//				
//			}
//		});
		
		//2)����2����ValueAnimator
//		ValueAnimator animator = ValueAnimator.ofFloat(0f,200f);
//		animator.setDuration(200);
//		animator.addUpdateListener(new AnimatorUpdateListener() {
//			
//			@Override
//			public void onAnimationUpdate(ValueAnimator animation) {
////				//������ִ�еĹ��̵��У����ϵص��ô˷���
//////			animation.getAnimatedFraction()//�ٷֱ�
////			//�õ�durationʱ���� values���е�ĳһ���м�ֵ��0f~100f
//				float value = (float) animation.getAnimatedValue();//
//				iv.setScaleX(0.5f+value/200);//0.5~1
//				iv.setScaleY(0.5f+value/200);//0.5~1
//			}
//		});
//		animator.start();
		//3������3
		//float... values:�����ؼ�֡��ֵ
//		PropertyValuesHolder holder1 = PropertyValuesHolder.ofFloat("alpha", 1f,0.7f,1f);
//		PropertyValuesHolder holder2 = PropertyValuesHolder.ofFloat("scaleX", 1f,0.7f,1f);
//		PropertyValuesHolder holder3 = PropertyValuesHolder.ofFloat("scaleY", 1f,0.7f,1f);
////		PropertyValuesHolder holder3 = PropertyValuesHolder.ofFloat("translationX", 0f,300f);
//		
//		ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(iv, holder1,holder2,holder3);
//		animator.setDuration(1000);
//		animator.addUpdateListener(new AnimatorUpdateListener() {
//			
//			@Override
//			public void onAnimationUpdate(ValueAnimator animation) {
//				// TODO Auto-generated method stub
//				float animatedValue = (float) animation.getAnimatedValue();
//				float animatedFraction = animation.getAnimatedFraction();
//				long playTime = animation.getCurrentPlayTime();
//				
//				System.out.println("animatedValue:"+animatedValue+",  playTime:"+playTime);
//			}
//		});
//		animator.start();
		//4)����4��-----------------��������--------------------
//		ObjectAnimator animator1 = ObjectAnimator.ofFloat(iv,"alpha", 1f,0.7f,1f);
//		ObjectAnimator animator2 = ObjectAnimator.ofFloat(iv,"scaleX", 1f,0.7f,1f);
//		ObjectAnimator animator3 = ObjectAnimator.ofFloat(iv,"scaleY", 1f,0.7f,1f);
//		
//		AnimatorSet animatorSet = new AnimatorSet();
//		animatorSet.setDuration(500);
////		animatorSet.play(anim);//ִ�е�������
////		animatorSet.playTogether(animator1,animator2,animator3);//ͬʱִ��
//		animatorSet.playSequentially(animator1,animator2,animator3);//����ִ�ж���
//		animatorSet.start();
		
		//4.-------------------������ʵ��������Ч��--------------------------
//		/**
//		 * x:����
//		 * y:���ٶ�   y=1/2*g*t*t
//		 * ʹ�ù�ֵ�����ʵ�֡�
//		 */
//		ValueAnimator valueAnimator = new ValueAnimator();
//		valueAnimator.setDuration(4000);
////		valueAnimator.setFloatValues(values)
//		valueAnimator.setObjectValues(new PointF(0, 0));
//		//��ֵ��---����������
//		valueAnimator.setEvaluator(new TypeEvaluator<PointF>() {
//
//			@Override
//			public PointF evaluate(float fraction, PointF startValue,
//					PointF endValue) {
//				//�õ�ÿһ��ʱ��������
//				//x=v*t (s��)
//				PointF pointF = new PointF();
//				pointF.x = 100f*(fraction*4);//��ʼ�ٶ�*(ִ�еİٷֱ�*4)
////				pointF.y = 0.5f*9.8f*(fraction*4)*(fraction*4);
//				pointF.y = 0.5f*150f*(fraction*4)*(fraction*4);
//				return pointF;
//			}
//		});
//		
//		valueAnimator.addUpdateListener(new AnimatorUpdateListener() {
//			
//			@Override
//			public void onAnimationUpdate(ValueAnimator animation) {
//				//�õ���ʱ��������
//				PointF pointF = (PointF) animation.getAnimatedValue();
//				
//				iv.setX(pointF.x);
//				iv.setY(pointF.y);
//			}
//		});
//		valueAnimator.start();
		
		
		ObjectAnimator oa = ObjectAnimator.ofFloat(v, "translationY", 0f,1100f);
		oa.setDuration(500);
		//���ü�����---
//		oa.setInterpolator(new AccelerateInterpolator(5));
//		oa.setInterpolator(new AccelerateDecelerateInterpolator());
//		oa.setInterpolator(new AnticipateInterpolator(8));
//		oa.setInterpolator(new OvershootInterpolator());
//		oa.setInterpolator(new CycleInterpolator(4));
		oa.setInterpolator(new BounceInterpolator());
		
		oa.start();
	}

}
