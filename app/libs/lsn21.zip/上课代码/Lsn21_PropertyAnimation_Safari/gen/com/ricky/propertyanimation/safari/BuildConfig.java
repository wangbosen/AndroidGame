/** Automatically generated file. DO NOT MODIFY */
package com.ricky.propertyanimation.safari;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}