package com.ricky.parallax;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

public class ParallaxContainer extends FrameLayout implements OnPageChangeListener {

	private List<ParallaxFragment> fragments;
	private float containerWidth;

	public ParallaxContainer(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		
	}

	public void setUp(int... ids ){
		fragments = new ArrayList<ParallaxFragment>();
		for (int i = 0; i <ids.length ; i++) {
			ParallaxFragment f = new ParallaxFragment();
			Bundle args = new Bundle();
			args.putInt("layoutId", ids[i]);
			f.setArguments(args );
			fragments.add(f);
		}
		
		//1.viewpager
		ViewPager vp = new ViewPager(getContext());
		vp.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		vp.setId(R.id.parallax_pager);
		
		ParallaxAdapter adapter = new ParallaxAdapter(((FragmentActivity)getContext()).getSupportFragmentManager(), fragments);
		vp.setAdapter(adapter);
		
		addView(vp, 0);
		
		vp.addOnPageChangeListener(this);
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int position, float positionOffset,
			int positionOffsetPixels) {
		containerWidth = getWidth();
		//�����ҳ��
		ParallaxFragment inFragment = null;
		try {
			inFragment = fragments.get(position-1);
		} catch (Exception e) {
		}
		//�˳���ҳ��
		ParallaxFragment outFragment = null;
		try {
			outFragment = fragments.get(position);
		} catch (Exception e) {
		}
		
		if(inFragment!=null){
			List<View> views = inFragment.getViews();
			for (int i = 0; i < views.size(); i++) {
				View view = views.get(i);
				ParallaxViewTag tag = (ParallaxViewTag) view.getTag(R.id.parallax_view_tag);
				Log.i("ricky", "tag_in:"+tag);
				if(tag==null) continue;
				//��������
				view.setTranslationX((containerWidth-positionOffsetPixels)*tag.xIn);
				view.setTranslationY((containerWidth-positionOffsetPixels)*tag.yIn);
				
			}
		}
		if(outFragment!=null){
			List<View> views = outFragment.getViews();
			for (int i = 0; i < views.size(); i++) {
				View view = views.get(i);
				ParallaxViewTag tag = (ParallaxViewTag) view.getTag(R.id.parallax_view_tag);
				Log.i("ricky", "tag_out:"+tag);
				if(tag==null) continue;
				//��������
				view.setTranslationX((-positionOffsetPixels)*tag.xOut);
				view.setTranslationY((-positionOffsetPixels)*tag.yOut);
				
			}
		}
	}

	@Override
	public void onPageSelected(int arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
