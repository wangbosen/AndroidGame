package com.ricky.parallax;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

public class ParallaxLayoutInflater extends LayoutInflater {

	private ParallaxFragment fragment;

	protected ParallaxLayoutInflater(LayoutInflater original, Context newContext,ParallaxFragment fragment) {
		super(original, newContext);
		this.fragment = fragment;
		setFactory(new ParallaxFactory(this));
	}

	@Override
	public LayoutInflater cloneInContext(Context newContext) {
		// TODO Auto-generated method stub
		return new ParallaxLayoutInflater(this, newContext,fragment);
	}
	
	//�Զ��幤����,��ͼ�����Ĺ�����
	class ParallaxFactory implements Factory{

		private LayoutInflater inflater;
		public ParallaxFactory(LayoutInflater inflater) {
			this.inflater = inflater;
		}
		@Override
		public View onCreateView(String name, Context context,
				AttributeSet attrs) {
			//1.ʵ���������view
			View view = null;
			if(view==null){
				view = createView(name,context,attrs);
			}
			Log.i("ricky", "view:"+view);
			if(view!=null){
				//��ȡ�Զ������ԣ������Զ����ǩֵ�󶨵�view����
				getCustomAttrs(context,attrs,view);
				fragment.getViews().add(view);
			}
			return view;
		}

		private void getCustomAttrs(Context context, AttributeSet attrs, View view) {
			//�����Զ��������
			int[] attrIds = {
					R.attr.a_in,
					R.attr.a_out,
					R.attr.x_in,
					R.attr.x_out,
					R.attr.y_in,
					R.attr.y_out,
			};
			
			TypedArray a = context.obtainStyledAttributes(attrs, attrIds);
			
			if(a!=null && a.length()>0){
				ParallaxViewTag tag = new ParallaxViewTag();
				tag.alphaIn = a.getFloat(0, 0f);
				tag.alphaOut = a.getFloat(1, 0f);
				tag.xIn = a.getFloat(2, 0f);
				tag.xOut = a.getFloat(3, 0f);
				tag.yIn = a.getFloat(4, 0f);
				tag.yOut = a.getFloat(5, 0f);
				view.setTag(R.id.parallax_view_tag, tag);
	//			view.setTag(obj);
			}
			a.recycle();
		}
		
		private final String[] prefixs = {
				"android.widget.",
				"android.view."
		};
		
		private View createView(String name, String prefix,Context context, AttributeSet attrs) {
			try {
				return inflater.createView(name, prefix, attrs);
			} catch (Exception e) {
				return null;
			}
		}
		
		private View createView(String name, Context context, AttributeSet attrs) {
			//ͨ��ϵͳ��inflater�ഴ����ͼ
			if(name.contains(".")){//�Զ���ؼ����Ѿ���ȫ������
				return createView(name, null,context, attrs);
			}else{
//				android.widget.ImageView   "android.widget."+name
//				android.view.SurfaceView
				for(String prefix:prefixs){
					View view =  createView(name, prefix, context, attrs);
					if(view!=null){
						return view;
					}
				}
			}
			
			return null;
		}
		
	}


}
