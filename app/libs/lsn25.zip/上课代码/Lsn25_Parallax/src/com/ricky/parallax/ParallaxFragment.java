package com.ricky.parallax;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ParallaxFragment extends Fragment {
	private List<View> views = new ArrayList<View>();
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Bundle bundle = getArguments();
		int layoutId = bundle.getInt("layoutId");
//		View view = inflater.inflate(layoutId, container);
		ParallaxLayoutInflater layoutInflater = new ParallaxLayoutInflater(inflater, getActivity(),this);
		return layoutInflater.inflate(layoutId, null);
	}

	public List<View> getViews() {
		return views;
	}

}
