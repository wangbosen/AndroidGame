/** Automatically generated file. DO NOT MODIFY */
package com.ricky.scenetransitionanimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}