package com.ricky.event;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

public class MyRelativeLayout extends RelativeLayout {

	public MyRelativeLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		Log.i("ricky", "dispatchTouchEvent:action--"+ev.getAction()+"---view:MyRelativeLayout");
		return super.dispatchTouchEvent(ev);
	}
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		Log.i("ricky", "onInterceptTouchEvent:action--"+ev.getAction()+"---view:MyRelativeLayout");
		return super.onInterceptTouchEvent(ev);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		Log.i("ricky", "onTouchEvent:action--"+event.getAction()+"---view:MyRelativeLayout");
		return super.onTouchEvent(event);
	}
	

}
