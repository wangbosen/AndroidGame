/** Automatically generated file. DO NOT MODIFY */
package com.ricky.materialdesign.fab.animation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}