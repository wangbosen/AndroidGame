/** Automatically generated file. DO NOT MODIFY */
package com.example.lsn8_materialdesign_slidingmenu_navigationview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}