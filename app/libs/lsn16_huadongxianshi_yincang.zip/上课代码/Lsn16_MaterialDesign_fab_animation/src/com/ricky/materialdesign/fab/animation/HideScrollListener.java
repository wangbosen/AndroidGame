package com.ricky.materialdesign.fab.animation;

public interface HideScrollListener {
	
	public void onHide();
	public void onShow();

}
