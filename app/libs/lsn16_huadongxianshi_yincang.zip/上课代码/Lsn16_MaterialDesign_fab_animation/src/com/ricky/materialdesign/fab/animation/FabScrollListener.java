package com.ricky.materialdesign.fab.animation;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;

public class FabScrollListener extends OnScrollListener {
	private static final int THRESHOLD = 20;
	private int distance = 0;
	private HideScrollListener hideListener;
	private boolean visible = true;//�Ƿ�ɼ�
	
	public FabScrollListener(HideScrollListener hideScrollListener) {
		// TODO Auto-generated constructor stub
		this.hideListener = hideScrollListener;
	}
	@Override
	public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
		super.onScrolled(recyclerView, dx, dy);
		/**
		 * dy:Y�᷽�������
		 * �����͸�
		 * ������ִ�ж�����ʱ�򣬾Ͳ�Ҫ��ִ����
		 */
		if(distance>THRESHOLD&&visible){
			//���ض���
			visible = false;
			hideListener.onHide();
			distance = 0;
		}else if(distance<-20&&!visible){
			//��ʾ����
			visible = true;
			hideListener.onShow();
			distance = 0;
		}
		if(visible&&dy>0||(!visible&&dy<0)){
			distance += dy;
		}
	}

}
